'use strict';

angular.module('sunatApp', [ 'tabs' ])
	.controller('TabsController', function() {
});
