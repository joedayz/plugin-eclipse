$(document).ready(function() {
	$('#datetimepicker1').datetimepicker({
		locale : 'es',
		format : 'DD/MM/YYYY'
	});

});
