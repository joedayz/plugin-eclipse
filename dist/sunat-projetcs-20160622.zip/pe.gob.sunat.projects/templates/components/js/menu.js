var app = angular.module('sunatApp', ['ui.bootstrap']);

app.controller('MenuController', function($scope) {
 
    $scope.items = [
        "The first choice!",
        "And another choice for you.",
        "but wait! A third!"
    ];
});
